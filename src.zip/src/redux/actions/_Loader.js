import * as actionTypes from "../_ActionTypes"


export const showLoader=()=>({
    type:actionTypes.SHOW_LOADER
})

export const hideLoader=()=>({
    type:actionTypes.HIDE_LOADER
})
