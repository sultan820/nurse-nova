import _MyMedicalReminders from "./_MyMedicalReminders"
import _AddNewReminder from "./_AddNewReminder"
import _MedicalReminderForm from "./_MedicalReminderForm"
import _MedicalReminderList from "./_MedicalReminderList"



export {
    _MyMedicalReminders,
    _AddNewReminder,
    _MedicalReminderForm,
    _MedicalReminderList,
    
}