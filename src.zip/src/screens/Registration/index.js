import AddPhoto from "./AddPhoto"
import CreateAccount from "./CreateAccount"




export  {
    AddPhoto,
    CreateAccount
}