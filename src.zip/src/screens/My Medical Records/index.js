import _MyMedicalRecords from "./_MyMedicalRecords"
import _AddNewMember from "./_AddNewMember"
import _MedicalRecordForm from "./_MedicalRecordForm"
import _MedicalRecordList from "./_MedicalRecordList"



export {
    _MyMedicalRecords,
    _AddNewMember,
    _MedicalRecordForm,
    _MedicalRecordList
}