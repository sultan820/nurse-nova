export const List=[
    {
        id:1,
        date:new Date(),
        description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur egestas imperdiet risus eget ornare. Nulla a ultrices libero. Fusce pharetra ante nisi, vitae tincidunt diam tincidunt a.",
        name:"Elie Tannous"
    },
    {
        id:2,
        date:new Date(),
        description:"Aliquam at elementum sem. Cras dignissim bibendum quam. Curabitur in neque placerat, aliquam lorem eget, pulvinar tellus",
        name:"Mark Tannous"
    },
    {
        id:3,
        date:new Date(),
        description:"Donec non lectus vel nibh luctus malesuada vel in sem. Interdum et malesuada fames ac ante ipsum primis in faucibus.",
        name:"James Tannous"
    },
]